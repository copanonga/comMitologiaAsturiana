<?php
defined('_JEXEC') or die;

class mitologiaasturianaController extends JControllerLegacy
{
    
    public function display($cachable = false, $urlparams = false)
    {

        parent::display();
        return $this;

    }
        
}