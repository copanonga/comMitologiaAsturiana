<?php
defined('_JEXEC') or die;

?>

<h1><?php echo JText::_( 'COM_MITOLOGIAASTURIANA' );?></h1>